
cd dashboard

cd .cascade-template-designs

bash cascade-template-design.bash
