https://apilayer.com/marketplace/checkiday-api

https://apilayer.com/marketplace/spell-api

https://apilayer.com/marketplace/keyword-api

https://apilayer.com/marketplace/tisane-api
