https://apilayer.com/docs/article/provider-faq

https://apilayer.com/provider
