Faraz Ahmed  ·
Below are the steps I used to hunt for projects when I was starting on Upwork, and I will use these steps again to hunt for clients in the future:
1. 𝐁𝐢𝐝 𝐛𝐞𝐭𝐰𝐞𝐞𝐧 5 p.𝐦. - 11 p.𝐦. CST Reason: There's usually less competition. I won most of my jobs between 6 p.m. and 9 p.m. CST
2. 𝐁𝐢𝐝 𝐨𝐧 𝐧𝐞𝐰 𝐜𝐥𝐢𝐞𝐧𝐭𝐬 𝐰𝐢𝐭𝐡 𝐮𝐧𝐯𝐞𝐫𝐢𝐟𝐢𝐞𝐝 𝐩𝐚𝐲𝐦𝐞𝐧𝐭 𝐦𝐞𝐭𝐡𝐨𝐝𝐬 Reason: Most people don't bid on projects from clients with no project history or unverified payment method, so the competition decreases further. Also, as an established client, I always prefer top-rated freelancers. That's why I suggest avoiding bidding on clients with a history when you're a beginner because they are highly unlikely to hire you. New clients mostly don't notice badges. They just want to get their work done, and the profile picture and the proposal are the two most important things for them. There's also another advantage to bidding on new clients, which is mentioned at the end.
3. 𝐁𝐢𝐝 𝐨𝐧 𝐬𝐦𝐚𝐥𝐥 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬. These projects will help you build your reputation on the platform quickly, gain some positive reviews, and get some experience under your belt, allowing you to bid on medium-sized and large-sized projects.
4. 𝐓𝐡𝐞 𝐟𝐢𝐫𝐬𝐭 𝟐𝟑𝟎 𝐜𝐡𝐚𝐫𝐚𝐜𝐭𝐞𝐫𝐬 𝐨𝐟 𝐲𝐨𝐮𝐫 𝐩𝐫𝐨𝐩𝐨𝐬𝐚𝐥 𝐚𝐫𝐞 𝐢𝐦𝐩𝐨𝐫𝐭𝐚𝐧𝐭. I use these characters to either: 1) Ask a question related to the project. 2) If I know the solution to the issue, I give a hint of the solution to the client, so they know I'm the right person for the job, along with the price and the time estimate, with a call to action to hire me now if they want me to fix the issue immediately. 𝐍𝐨𝐭𝐞: This tip of mine was also endorsed by Upwork itself in one of their articles.
5. 𝐀𝐟𝐭𝐞𝐫 𝐭𝐡𝐞 𝐜𝐥𝐢𝐞𝐧𝐭 𝐬𝐞𝐧𝐝𝐬 𝐲𝐨𝐮 𝐭𝐡𝐞 𝐨𝐟𝐟𝐞𝐫, 𝐞𝐧𝐬𝐮𝐫𝐞 𝐭𝐡𝐞 𝐭𝐰𝐨 𝐭𝐡𝐢𝐧𝐠𝐬 𝐛𝐞𝐥𝐨𝐰 𝐛𝐞𝐟𝐨𝐫𝐞 𝐚𝐜𝐜𝐞𝐩𝐭𝐢𝐧𝐠 𝐭𝐡𝐞 𝐨𝐟𝐟𝐞𝐫:
a) Make sure you have all the project details, and you are 100% certain of what you need to do in the project. Don't accept the offer in excitement. Ensure you have all the details first.
b) Confirm that the client has verified their payment method by now. If not, ask them to do so. If they are a legitimate client, they will, and you can accept the offer. If not, they might make excuses. If they do the latter, reject the offer. You'll waste your Connects, but you'll save yourself from a scam.
c) It's important to heed the above steps for new clients because if the client turns out to be a scammer after you accept the offer, and even if you cancel the contract without working on it, the client can still give you private feedback (not public, though). And if they give poor private feedback, your profile will take a hit!
6. 𝐎𝐧𝐜𝐞 𝐲𝐨𝐮 𝐚𝐜𝐜𝐞𝐩𝐭 𝐭𝐡𝐞 𝐨𝐟𝐟𝐞𝐫, 𝐨𝐯𝐞𝐫𝐝𝐞𝐥𝐢𝐯𝐞𝐫! If the client has asked you to do one thing, do two! The goal is to make the client's first experience with their initial freelancer as positive as possible! Because if they're pleased with your work and have more work in the future, they'll always return to you!
If you follow the steps above, there's a high chance you'll come across some long-term clients who will provide regular work, allowing you to avoid the constant bidding war. All you need are a few long-term clients to generate a stable income in your freelancing career. That's how I've thrived for the last 10 years.


Read the job description properly, secondly bid the job at the right time, remember your first three lines are the most important, link some your portfolios in your proposal proposal that's all


Michael Alpiner
Morgan Michaels Depends on the size of the blogs, but either 75 cents a word or a project price between 750 and 1500 dollars. You get what you pay for, as they say...I am a writing professor, MFA in Creative Writing, and my work has appeared in Forbes, NY Post, Business Traveler Magazine, etc
