cut the fan on

open the windows

bleach my hands again

check on the shorts

cuz on first things first

get a github pages up and see what happens.

recover the password from my github page over on troyburney

move trash to the other room

bag up trash on the floor

bag up the spray bottle and tie off

spray the mattresss multiple times with bleach and smell good

scrub my feet so they can smell good

soak my feet while i compute

buddhist music in the backgroudn on my computer

emby server set up


