# article magick speed run

## metadata

start / 10.24

## the back end

[`done`] get the project pulled down

[`done`] add api documentation with mkdocs

[`done`] get the app up

[`done`] push api to github

[`done`] rename the projects in github

[`done`] git prune the repo

update build automation

release github pages site of the api documentation

git prune the repo

## the front end

[`done`] get the project pulled down

[`done`] get the app up

[`done`] import in the software shinobi dashboard contents

[`done`] rename the projects in github

[`done`] integrate the rewrite calculation into the dashboard

[`done`] push dashboard to github

[`done`] git prune the repo

release github pages site of the dashboard

## the marketing

tbd
