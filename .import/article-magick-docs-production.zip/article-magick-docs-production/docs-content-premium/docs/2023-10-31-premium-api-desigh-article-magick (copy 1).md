---

layout: post

author: softwareshinobi

title:  "lorem ipsum sed"

categories: [lorem-ipsum]

tags: [lorem-ipsum,lorem,ipsum]

image: https://random.imagecdn.app/820/360

description: "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti."

hidden: false

---

## Project

Article Magick

## intention of this project

i want this project to make me 100k COP daily averaged from paid apis about text conversions.

## quick links

### google document with napkin math


## api design

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis id massa ultricies bibendum. Praesent non lorem a nunc faucibus lacinia nec eget sem. Duis nulla odio, sodales a nisi sit amet, congue pellentesque neque. Suspendisse lacus lorem, ultricies at rhoncus et, dapibus vitae tellus. In hac habitasse platea dictumst. Etiam convallis eleifend lectus, ac vulputate enim ullamcorper sit amet. Vivamus egestas augue sed arcu consequat volutpat.

## api pricing

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis id massa ultricies bibendum. Praesent non lorem a nunc faucibus lacinia nec eget sem. Duis nulla odio, sodales a nisi sit amet, congue pellentesque neque. Suspendisse lacus lorem, ultricies at rhoncus et, dapibus vitae tellus. In hac habitasse platea dictumst. Etiam convallis eleifend lectus, ac vulputate enim ullamcorper sit amet. Vivamus egestas augue sed arcu consequat volutpat.

## api documentation

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis id massa ultricies bibendum. Praesent non lorem a nunc faucibus lacinia nec eget sem. Duis nulla odio, sodales a nisi sit amet, congue pellentesque neque. Suspendisse lacus lorem, ultricies at rhoncus et, dapibus vitae tellus. In hac habitasse platea dictumst. Etiam convallis eleifend lectus, ac vulputate enim ullamcorper sit amet. Vivamus egestas augue sed arcu consequat volutpat.

## api creation

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis id massa ultricies bibendum. Praesent non lorem a nunc faucibus lacinia nec eget sem. Duis nulla odio, sodales a nisi sit amet, congue pellentesque neque. Suspendisse lacus lorem, ultricies at rhoncus et, dapibus vitae tellus. In hac habitasse platea dictumst. Etiam convallis eleifend lectus, ac vulputate enim ullamcorper sit amet. Vivamus egestas augue sed arcu consequat volutpat.

## api unit testing

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis id massa ultricies bibendum. Praesent non lorem a nunc faucibus lacinia nec eget sem. Duis nulla odio, sodales a nisi sit amet, congue pellentesque neque. Suspendisse lacus lorem, ultricies at rhoncus et, dapibus vitae tellus. In hac habitasse platea dictumst. Etiam convallis eleifend lectus, ac vulputate enim ullamcorper sit amet. Vivamus egestas augue sed arcu consequat volutpat.

## api security

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis id massa ultricies bibendum. Praesent non lorem a nunc faucibus lacinia nec eget sem. Duis nulla odio, sodales a nisi sit amet, congue pellentesque neque. Suspendisse lacus lorem, ultricies at rhoncus et, dapibus vitae tellus. In hac habitasse platea dictumst. Etiam convallis eleifend lectus, ac vulputate enim ullamcorper sit amet. Vivamus egestas augue sed arcu consequat volutpat.

## api deployment

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis id massa ultricies bibendum. Praesent non lorem a nunc faucibus lacinia nec eget sem. Duis nulla odio, sodales a nisi sit amet, congue pellentesque neque. Suspendisse lacus lorem, ultricies at rhoncus et, dapibus vitae tellus. In hac habitasse platea dictumst. Etiam convallis eleifend lectus, ac vulputate enim ullamcorper sit amet. Vivamus egestas augue sed arcu consequat volutpat.

## Intention

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis id massa ultricies bibendum. Praesent non lorem a nunc faucibus lacinia nec eget sem. Duis nulla odio, sodales a nisi sit amet, congue pellentesque neque. Suspendisse lacus lorem, ultricies at rhoncus et, dapibus vitae tellus. In hac habitasse platea dictumst. Etiam convallis eleifend lectus, ac vulputate enim ullamcorper sit amet. Vivamus egestas augue sed arcu consequat volutpat.
