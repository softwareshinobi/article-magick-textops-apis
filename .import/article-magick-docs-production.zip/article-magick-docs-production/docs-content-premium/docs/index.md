# Article Magick API

what's up!

these are the docs.
