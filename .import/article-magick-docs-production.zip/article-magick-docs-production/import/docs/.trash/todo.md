## rest endpoi99n9ts


there needs to be a setup on the / endpo9i9nt

the debug page needs to be d9isable

how to 9i load up the rest api9 docs to do 9with my shit

how do i9 deploy the java docs into a styled website

how to deploy javascots 9into a docker image
