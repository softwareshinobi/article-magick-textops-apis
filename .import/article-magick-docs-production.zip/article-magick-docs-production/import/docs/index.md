# Napkin Exchange Docs

For full documentation visit [mkdocs.org](https://www.mkdocs.org).

## Candles

needs to generate spread

needs to generate 1M candles

needs to generate 5M candles

## orders

[`later`] needs to provide a user registration that will multiple tenants

place an order and be able to view it's performance
