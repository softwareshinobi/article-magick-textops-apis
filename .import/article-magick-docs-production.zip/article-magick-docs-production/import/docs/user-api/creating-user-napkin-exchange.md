# The Account API

## viewing all accounts


## creating new account

```
curl -X POST -H "Content-Type: application/json" -d '{"username":"sasuke","email":"linuxize@example.com"}' http://localhost:4444/account/create
```

## getting account details

## set account balance

## view account inventory

## buy unit of currency
