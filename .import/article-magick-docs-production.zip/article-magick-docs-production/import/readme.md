## get all the candles for all the currencies

http://localhost:9999/candlestick/detailed

## get all the candles for a single currency

```
http://localhost:9999/candlestick/CALLISTO
```

